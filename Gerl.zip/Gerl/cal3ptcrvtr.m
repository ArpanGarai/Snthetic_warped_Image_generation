function [ C ] = cal3ptcrvtr( xa,ya,xb,yb,xc,yc)
    a = sqrt((xa-xb).^2+(ya-yb).^2); % The three sides
    b = sqrt((xb-xc).^2+(yb-yc).^2);
    c = sqrt((xc-xa).^2+(yc-ya).^2);
    s = (a+b+c)/2;
    A = sqrt(s.*(s-a).*(s-b).*(s-c)); % Area of triangle
    if (a.*b.*c) ~= 0
        C = 4.*A/(a.*b.*c);
    else
        C = 1;
    end
end

