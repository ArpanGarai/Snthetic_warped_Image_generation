function [ op_A ] = warp_rgb(Ab,d_r,d_c)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
[imR, imC, ch] = size(Ab);
idx = zeros(imR, imC,'uint8');
op_A = zeros(imR, imC, class(Ab));
% op_A = imcomplement(op_A);
% j = 1:imC;
% rot_bayas_i = max(j.*rot_A(1,j));
top_sft = min(d_r(1,:));
if top_sft > 0
    top_sft = 0;
end
top_sft = abs(top_sft);
for i = 1:imR
    for j = 1:imC
        %         for k = 1:3
        i1 = max(1,round(i+d_r(i,j)+top_sft));
        j1 = max(1,round(j+d_c(i,j)));
        %         j1 = max(1,floor(j+i*rot_A(i,j)));
        op_A(i1,j1,1)= Ab(i,j,1);
        op_A(i1,j1,2)= Ab(i,j,2);
        op_A(i1,j1,3)= Ab(i,j,3);
        idx(i1,j1) = 1;
% %         if(j1 > 2 && i1 > 2 )
% %             op_A(i1,j1-1,1)= Ab(i,j,1);
% %             op_A(i1,j1-1,2)= Ab(i,j,2);
% %             op_A(i1,j1-1,3)= Ab(i,j,3);
% %             op_A(i1,j1+1,1)= Ab(i,j,1);
% %             op_A(i1,j1+1,2)= Ab(i,j,2);
% %             op_A(i1,j1+1,3)= Ab(i,j,3);
% %             op_A(i1-1,j1,1)= Ab(i,j,1);
% %             op_A(i1-1,j1,2)= Ab(i,j,2);
% %             op_A(i1-1,j1,3)= Ab(i,j,3);
% %             op_A(i1+1,j1,1)= Ab(i,j,1);
% %             op_A(i1+1,j1,2)= Ab(i,j,2);
% %             op_A(i1+1,j1,3)= Ab(i,j,3);
% %         end
        %             i1 = max(1,ceil(i+d_r(i,j)));
        %             j1 = max(1,ceil(j+d_c(i,j)));
        %             %         j1 = max(1,ceil(j+i*rot_A(i,j)));
        %             op_A(i1,j1,1)= Ab(i,j,1);
        %             op_A(i1,j1,2)= Ab(i,j,2);
        %             op_A(i1,j1,3)= Ab(i,j,3);
        %         end
    end
end
[idxr, idxc] = size(idx);
for i = 2:idxr-1
    for j = 2:idxc-1
        if idx(i,j) == 0
            midx = idx(i-1:i+1,j-1:j+1);
            mop_A1 = op_A(i-1:i+1,j-1:j+1,1);
            mop_A2 = op_A(i-1:i+1,j-1:j+1,2);
            mop_A3 = op_A(i-1:i+1,j-1:j+1,3);
            s = sum(sum( midx == 1));
            sum1 = sum(sum(mop_A1 .* midx));
            sum2 = sum(sum(mop_A2 .* midx));
            sum3 = sum(sum(mop_A3 .* midx));
            op_A(i,j,1) = sum1/s;
            op_A(i,j,2) = sum2/s;
            op_A(i,j,3) = sum3/s;
        end
    end
end
   
end

