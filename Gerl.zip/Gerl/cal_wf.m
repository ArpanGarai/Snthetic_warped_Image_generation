function [d_r, d_c] = cal_wf(imR, imC,depth,alpha_r, alpha_c) %,crv_doc,theta
d_r = zeros(imR,imC);
d_c = zeros(imR,imC);
d_r = depth.*tand(alpha_r);
 
% c_c = round(imC*cntr(2));
% for i = 1:imR
%     C_dist(i,:) = abs((1:imC)-c_c);
% end
% d_cntr = depth(round(imR*cntr(1)),round(imC*cntr(2)));
% d1 = depth - d_cntr;
% theta = atand(d1./C_dist);
% theta(1:imR,c_c) = 0;

% A = p > depth;
% theta = A.*asind(depth./p);
%     

% d_c1 = depth.*(tand(alpha_c) + (crv_doc.*cosd(crv_doc./2)./(cosd(theta).*sind(crv_doc))) + tand(theta));
d_c = depth.*(tand(alpha_c));
end