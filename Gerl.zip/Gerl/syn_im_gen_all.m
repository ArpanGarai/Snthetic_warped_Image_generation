% Written by: Arpan Garai



clear all;
close all;
linux = 1;
if linux == 0
    ippath = 'C:\Users\CST\Documents\PhD\Matlab_code\input_images\Bengali IIESTS Database\GroundTruth\Binary_Text_only\';

op_pth_im = 'C:\Users\arpan\Documents\PhD\Matlab_code\input_images\Syn_img\syn_img_small_1\';
op_pth_gt_c = 'C:\Users\arpan\Documents\PhD\Matlab_code\input_images\Syn_img\gt_im\c\';
op_pth_gt_r = 'C:\Users\arpan\Documents\PhD\Matlab_code\input_images\Syn_img\gt_im\r\';

else
%     ippath = 'C:\Users\arpan\Documents\PhD\Matlab_code\input_images\Bengali IIESTS Database\GroundTruth\binarised_new_small\';
 
 %   ippath = '/home/arpan/Documents/PhD/Matlab_code/input_images/Bengali IIESTS Database/GroundTruth/line_seg_gt_small/';
 %   ippath_o = '/home/arpan/Documents/PhD/Matlab_code/input_images/Bengali IIESTS Database/GroundTruth/Binary_Text_only/';
 %   op_pth_im = '/home/arpan/Documents/PhD/Matlab_code/input_images/Syn_img/syn_img_small_1/';
 %   op_pth_im_o = '/home/arpan/Documents/PhD/Matlab_code/input_images/Syn_img/syn_img_org/';
 %   op_pth_gt_c = '/home/arpan/Documents/PhD/Matlab_code/input_images/Syn_img/gt_im/c/';
 %   op_pth_gt_r = '/home/arpan/Documents/PhD/Matlab_code/input_images/Syn_img/gt_im/r/';


    ippath = pwd;
    ippath_o = pwd;
    ippath_rgb = pwd;
    op_pth_im = pwd;
    op_pth_im_o = pwd;
    op_pth_gt_c = pwd;
    op_pth_gt_r = pwd;

end

for i = 6:6
ipflnm = ['GT_B00' int2str(i) '.tiff'];
[flname,flext] = strtok(ipflnm,'.');
A = imread([ippath ipflnm]);

ipflnm_o = ['B00' int2str(i) '_GT_Text_only.png'];
[flname_o,flext_o] = strtok(ipflnm_o,'.');
A_o = imread([ippath_o ipflnm_o]);
Agry = rgb2gray(A_o);
A_o = imbinarize(Agry,'adaptive','ForegroundPolarity','dark','Sensitivity',0.45);

ipflnm_rgb = ['B00' int2str(i) 'GTRGB.jpg'];
[flname_rgb,flext_rgb] = strtok(ipflnm_rgb,'.');
A_rgb = imread([ippath_rgb ipflnm_rgb]);
%Agry = rgb2gray(A_rgb);
%A_o = imbinarize(Agry,'adaptive','ForegroundPolarity','dark','Sensitivity',0.45);

cnt =1;

%% Specify the parameters
[imR, imC] = size(A);
imD = sqrt(imR^2+imC^2);

[imRo, imCo] = size(A_o);
imDo = sqrt(imRo^2+imCo^2);

[imRrgb, imCrgb, ch] = size(A_rgb);
imDrgb = sqrt(imRrgb^2+imCrgb^2);

R = 250;
OP = zeros(R,R);
DR = zeros(R,R,3);
DC = zeros(R,R,3);
% fac = 0.09;

%for fac1 = 0.03:0.02:0.09
fac1 =0.05;
    %for fac2 = 0.03:0.02:0.09
    fac2 = 0.05;
        for brk_i = [0.1 0.9]
            brk_t = brk_i;
            brk_b = brk_i;

     %       for c1 = [0.3 0.5 0.7]
      %          for c2 = [0.3 0.5 0.7]
		c1 = 0.5;
		c2 = 0.5;

                   % for cm_angle = [ 3 1.5 0 1.5 -3 ]
		cm_angle = 1.5;
%% For binary Image
                        
                         w_fac_t_lo = imDo*fac1;
                         w_fac_t_ro = imDo*fac2;
                         w_fac_b_lo = imDo*fac1;
                         w_fac_b_ro = imDo*fac2;
                         % brk_t = 0.2;
                         % brk_b = 0.2;
                         cm_d = imCo; %% Camera distance
                         %                         cm_angle = -1;
                         cntr = [c1, c2];
                         
                         %% Warped Image generation
                         [depth, theta] = cal_depth(imRo, imCo, w_fac_t_lo, w_fac_b_lo, w_fac_t_ro, w_fac_b_ro, brk_t, brk_b);
                         depth = add_angle(depth,cm_angle,cntr);
                         [arc_ln, y_arc, a, p, thta] = arc_len(imRo, imCo, depth, cntr);
                         [alphaR, alphaC] = cal_alpha(imRo, imCo, cntr, cm_d, a, p, depth, thta, y_arc);
                         
                         
                         [d_r, d_c] = cal_wf(imRo, imCo,depth, alphaR, alphaC);
                         op_Ao = warp(~A_o,d_r,d_c);
                         opflnm = ['/wrp' flname_o '_' int2str(cnt) flext_o];
                         imwrite(~op_Ao,[op_pth_im_o opflnm]);
%% for small image for Network   
                        
                        
                        w_fac_t_l = imD*fac1;
                        w_fac_t_r = imD*fac2;
                        w_fac_b_l = imD*fac1;
                        w_fac_b_r = imD*fac2;
                        % brk_t = 0.2;
                        % brk_b = 0.2;
                        cm_d = imC; %% Camera distance
                        %                         cm_angle = -1;
                        cntr = [c1, c2];
                        
                        %% Warped Image generation
                        [depth, theta] = cal_depth(imR, imC, w_fac_t_l, w_fac_b_l, w_fac_t_r, w_fac_b_r, brk_t, brk_b);
                        depth = add_angle(depth,cm_angle,cntr);
                        [arc_ln, y_arc, a, p, thta] = arc_len(imR, imC, depth, cntr);
                        [alphaR, alphaC] = cal_alpha(imR, imC, cntr, cm_d, a, p, depth, thta, y_arc);
                        
                        
                        [d_r, d_c] = cal_wf(imR, imC,depth, alphaR, alphaC);
                        op_A = warp(~A,d_r,d_c);
                        [or, oc] = size(op_A);
                        difr=floor((R-or)/2);
                        difc=floor((R-oc)/2);
                        OP(difr+1:or+difr,difc+1:oc+difc) = op_A;
                        opflnm = ['/wrp' flname '_' int2str(cnt) flext];                        
			imwrite(~OP,[op_pth_im opflnm]);
%% For RGB Image
                        
                         w_fac_t_lrgb = imDrgb*fac1;
                         w_fac_t_rrgb = imDrgb*fac2;
                         w_fac_b_lrgb = imDrgb*fac1;
                         w_fac_b_rrgb = imDrgb*fac2;
                         % brk_t = 0.2;
                         % brk_b = 0.2;
                         cm_d = imCrgb; %% Camera distance
                         %                         cm_angle = -1;
                         cntr = [c1, c2];
                         
                         %% Warped Image generation
                         [depth, theta] = cal_depth(imRrgb, imCrgb, w_fac_t_lrgb, w_fac_b_lrgb, w_fac_t_rrgb, w_fac_b_rrgb, brk_t, brk_b);
                         depth = add_angle(depth,cm_angle,cntr);
                         [arc_ln, y_arc, a, p, thta] = arc_len(imRrgb, imCrgb, depth, cntr);
                         [alphaR, alphaC] = cal_alpha(imRrgb, imCrgb, cntr, cm_d, a, p, depth, thta, y_arc);

                         
                         
                         [d_r, d_c] = cal_wf(imRrgb, imCrgb,depth, alphaR, alphaC);
			 op_A_rgb = warp_rgb(A_rgb,d_r,d_c);
                         opflnm = ['/wrp' flname_rgb '_' int2str(cnt) flext_rgb];
                         imwrite(~OP_A_rgb,[op_pth_im opflnm]);



                        
%                         figure, imshow(~op_A);
                        
                     %   [dw_A, ds_r, ds_c] = dewarp(op_A, d_r, d_c);
                        
                        
                      %  [or, oc] = size(ds_r);
                      %  difr=floor((R-or)/2);
                      %  difc=floor((R-oc)/2);
                      %  DR(difr+1:or+difr,difc+1:oc+difc,1) = ds_r;
                      %  DR(difr+1:or+difr,difc+1:oc+difc,2) = ds_r;
                      %  DR(difr+1:or+difr,difc+1:oc+difc,3) = ds_r;
                      %  [or, oc] = size(ds_r);
                      %  difr=floor((R-or)/2);
                      %  difc=floor((R-oc)/2);
                      %  DC(difr+1:or+difr,difc+1:oc+difc,1) = ds_c;
                      %  DC(difr+1:or+difr,difc+1:oc+difc,2) = ds_c;
                      %  DC(difr+1:or+difr,difc+1:oc+difc,3) = ds_c;
                       



 %% wirte the image
                        %                             if home == 0
                        %                                 oppath = ['C:\Users\CST\Documents\PhD\Matlab_code\Data_generation\Generated_images\' ipflnm(1:4) '\'];
                        %                             else
                        %                                 oppath = ['C:\Users\arpan\Documents\PhD\Matlab_code\Data_generation\Generated_images\' ipflnm(4:7) '\']; %ipflnm(1:4)
                        %                             end
                        
%                         dlmwrite([op_pth_gt 'ds_r' flname '_' int2str(cnt) '.txt'], ds_r);
%                         dlmwrite([op_pth_gt 'ds_c' flname '_' int2str(cnt) '.txt'], ds_c);
% %                         dlmwrite([op_pth_gt 'ds_r' flname '_' int2str(cnt) '.txt'], DR);
% %                         dlmwrite([op_pth_gt 'ds_c' flname '_' int2str(cnt) '.txt'], DC);
% % %                         imwrite(uint8(round(DR)),[op_pth_gt_r 'ds_r' flname '_' int2str(cnt) '.png']);
% % %                         imwrite(uint8(round(DC)),[op_pth_gt_c 'ds_c' flname '_' int2str(cnt) '.png']);
% % %                         
%                        imwrite(uint8(round(DR(:,:,1))),[op_pth_gt_r 'ds_r' flname '_' int2str(cnt) '.pgm']);
%                        imwrite(uint8(round(DC(:,:,1))),[op_pth_gt_c 'ds_c' flname '_' int2str(cnt) '.pgm']);
                        
                        
                        %opflnm = [flname 'wrpd' '_' int2str(w_fac_t_l) '_' int2str(w_fac_t_r) '_' int2str(w_fac_b_l) '_' int2str(w_fac_b_r) '_0.' int2str(10*brk_t) '_0.' int2str(10*brk_b) '_C0.' int2str(10*cntr(1)) 'C_0.' int2str(10*cntr(2)) 'phi_' int2str(cm_angle) flext];


   %%%%                     opflnm = [flname '_' int2str(cnt) flext];

                        %opflnm_rgb = [flname 'wrpd_rgb_' '_' int2str(w_fac_t_l) '_' int2str(w_fac_t_r) '_' int2str(w_fac_b_l) '_' int2str(w_fac_b_r) '_0.' int2str(10*brk_t) '_0.' int2str(10*brk_b) '_C0.' int2str(10*cntr(1)) 'C_0.' int2str(10*cntr(2)) 'phi_' int2str(cm_angle)  flext];
%                         imwrite(~op_A,[op_pth_im opflnm]);


       %%%                 imwrite(~OP,[op_pth_im opflnm]);


                        cnt = cnt + 1;


                        %imwrite(op_A_rgb,[oppath opflnm_rgb]);
                    %end
                %end
            %end
        end
    %end
%end

end
