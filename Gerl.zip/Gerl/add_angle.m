function [depth] = add_angle(depth,angl,cntr)
[imR, imC] = size(depth);
imR_c = imR * cntr(1);
for i = 1:imR
    depth(i,:) = depth(i,:) + (imR_c - i)*tand(angl);
end
end

