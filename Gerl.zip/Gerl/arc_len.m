function [arc_ln,y_arc, a, p, thta] = arc_len(imR, imC, depth, cntr)
arc_ln = zeros(imR,imC,'double');
a = zeros(imR,imC);
p = zeros(imR,imC);
thta = zeros(imR,imC);
c_pt = round(imC*cntr(2));
cnt = 0;
a1 = zeros(imC,1);
x = 1:imC;
a1 = abs(x-c_pt);
cnt2 = 0;
for i = 1:round(imC/20):imC
    cnt = cnt + 1;
    if i< c_pt
        y1(cnt) = len_arc(depth(1,i:c_pt),i:c_pt);
        for j=1:c_pt
            if a1(j) == round(y1(cnt))
                cnt2 = cnt2 + 1;
                x2(cnt2) = j;
                y2(cnt2) = i;
            end
        end
    else
        y1(cnt) = len_arc(depth(1,c_pt:i),c_pt:i);
        for j=c_pt:imC
            if a1(j) == round(y1(cnt))
                cnt2 = cnt2 + 1;
                x2(cnt2) = j;
                y2(cnt2) = i;
            end
        end
    end
    x1(cnt) = i;
end
[fitresult, gof] = createFit(x1, y1, 0.1, 50);
y = feval(fitresult,x);

[fitresult, gof] = createFit(x2, y2, 0.1, 50);
y_arc = round(feval(fitresult,x));

d1_cntr = depth(1,c_pt);
p1 = sqrt((depth(1,y_arc)-d1_cntr).^2 + (y_arc'-c_pt).^2);
% cnt = 0;
% for i = 1:round(imC/10):imC
%     if y_arc(i)-c_pt > 3
%         cnt = cnt + 1;
%         thta1y(cnt) = atand((depth(1,y_arc(i))-d1_cntr)./(y_arc(i)-c_pt));
%         thta1x(cnt) = i;
%     end
% end
% 
% [fitresult, gof] = createFit(thta1x, thta1y, 0.1, 50);
% thta1 = round(feval(fitresult,x));

thta1 = atand((depth(1,y_arc)-d1_cntr)./(y_arc'-c_pt));

for i = 1:imR
    arc_ln(i,:) = y;
    a(i,:) = a1;
    p(i,:) = p1;
    thta(i,:) = thta1;
end

end

function [l] = len_arc( x, y)
n = numel(x);
l = 0.0;
for i = 1:n-1
  l = l + sqrt( (x(i+1)-x(i))^2 + (y(i+1)-y(i))^2 );
end

end