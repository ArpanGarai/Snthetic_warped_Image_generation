function [alpha_r, alpha_c, alpha, E_dist] = cal_angl(imR, imC, depth, cntr, cm_d,crv_doc)
alpha = zeros(imR, imC);
beta = zeros(imR, imC);
c_r = round(imR*cntr(1));
c_c = round(imC*cntr(2));
R_dist = zeros(imR, imC);
for i = 1:imC
%     R_dist(:,i) = abs((1:imR)-c_r);
    R_dist(:,i) = c_r-(1:imR);
end
C_dist = zeros(imR, imC);
for i = 1:imR
%     C_dist(i,:) = abs((1:imC)-c_c);
    C_dist(i,:) = c_c-(1:imC);
end
E_dist = zeros(imR, imC);
E_dist = sqrt(R_dist.^2 + C_dist.^2);
% E_dist = E_dist/cm_d;
beta = atand(E_dist/cm_d);
alpha = acotd((E_dist.*cotd(beta) +depth)./(E_dist-depth.*tan(crv_doc/2)));

beta_r = atand(R_dist/cm_d);
alpha_r = acotd((R_dist.*cotd(beta_r) +depth)./(R_dist-depth.*tan(crv_doc/2)));
for i=1:imR
    if isnan(alpha_r(i,:))
        alpha_r(i,:) = alpha_r(i-1,:);
    end
end

beta_c = atand(C_dist/cm_d);
alpha_c = acotd((C_dist.*cotd(beta_c) +depth)./(C_dist-depth.*tan(crv_doc/2)));
for i=1:imC
    if isnan(alpha_c(:,i))
        alpha_c(:,i) = alpha_c(:,i-1);
    end
end
end

