function [crv_doc] = cal_crvature(imR,imC, depth)
crv_doc = zeros(imR,imC);
no_brk = 12;
stp = round(imC/no_brk);
c = zeros(1,no_brk-2);
id_c = zeros(1,no_brk-2);
% i = 1:imR;
    i = 1;
    for j = 2*stp:stp:(imC-stp)
        idx_r = depth(i,j);
        idx_c = j;
        idx_prv_r = depth(i,j-stp);
        idx_prv_c = j-stp;
        idx_nxt_r = depth(i,j+stp);
        idx_nxt_c = j+stp;
        c(round(j/stp)-1) = cal3ptcrvtr(idx_r,idx_c,idx_prv_r,idx_prv_c,idx_nxt_r,idx_nxt_c);
        id_c(round(j/stp)-1) = j;
     end
    fac_y = c;
    fac_x = id_c;
    [fitresult, gof] = createFit(fac_x, fac_y, 0.001,50);
    fac_x1 = 1:imC;
    fac_r = feval(fitresult, fac_x1);
    for i = 1:imR
        crv_doc(i, :) = fac_r;
    end
%      crv_doc(i, :) = fac_r;
% end

end

