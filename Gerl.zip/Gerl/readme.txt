Run: syn_im_gen_all.m


Example Input image:

Rgb image: B006GTRGB.jpg

Preprocessed image: B006_GT_Text_only.png

line segmented image for CNN input: GT_B006.tiff

Corresponding Output:

Rgb image: wrpB006GTRGB1.jpg

Preprocessed image: wrpB006_GT_Text_only1.png

line segmented image for CNN input: wrpGT_B0061.tiff

